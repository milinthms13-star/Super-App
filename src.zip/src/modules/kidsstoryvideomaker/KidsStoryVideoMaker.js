import React, { useEffect, useMemo, useState } from "react";
import "./KidsStoryVideoMaker.css";

const LANGUAGE_OPTIONS = [
  { id: "english", label: "English", code: "en-US" },
  { id: "hindi", label: "Hindi", code: "hi-IN" },
  { id: "malayalam", label: "Malayalam", code: "ml-IN" },
];

const STYLE_OPTIONS = [
  { id: "cartoon", label: "Cartoon", description: "Bright animations, playful characters, and joyful motion." },
  { id: "storybook", label: "Storybook", description: "Illustrated scenes with gentle textures and dreamy storytelling." },
  { id: "anime", label: "Anime", description: "Vivid characters, dramatic movement, and cinematic energy." },
  { id: "puppet", label: "Puppet", description: "Warm stage-style motion with charming puppetry feel." },
  { id: "three-d", label: "3D", description: "Modern 3D look with depth, camera moves, and polished animation." },
];

const VIDEO_SIZE_OPTIONS = [
  { id: "youtube", label: "YouTube (16:9)" },
  { id: "shorts", label: "Shorts (9:16)" },
  { id: "whatsapp", label: "WhatsApp (1:1)" },
];

const VOICE_OPTIONS = [
  { id: "kid-female", label: "Kid Female" },
  { id: "kid-male", label: "Kid Male" },
  { id: "soft-female", label: "Soft Female" },
  { id: "warm-male", label: "Warm Male" },
  { id: "magic-robot", label: "Magic Robot" },
];

const DEFAULT_STORY_PROMPT =
  "A curious child discovers a glowing map in the attic and sets off on a magical journey to make new friends.";

const AUTO_CHARACTER_LIBRARY = [
  { id: "minku-rabbit", name: "Minku Rabbit", role: "Hero", voice: "Kid Female" },
  { id: "luna-fairy", name: "Luna Fairy", role: "Guide", voice: "Soft Female" },
  { id: "bruno-bear", name: "Bruno Bear", role: "Friend", voice: "Warm Male" },
  { id: "foxy", name: "Foxy", role: "Trickster", voice: "Kid Male" },
];

const getStyleDescription = (styleId) => {
  const style = STYLE_OPTIONS.find((item) => item.id === styleId);
  return style ? style.description : "An expressive animation style for kids.";
};

const generateStoryTitle = (storyPrompt) => {
  const lines = storyPrompt
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);

  const firstLine = lines[0] || DEFAULT_STORY_PROMPT;
  const cleaned = firstLine.replace(/[^a-zA-Z0-9 ]/g, "").trim();
  return cleaned.length > 30 ? `${cleaned.slice(0, 30)}...` : cleaned || "Magical Story Adventure";
};

const autoDetectCharacters = (story) => {
  const text = story.toLowerCase();
  const detected = [];

  if (text.includes("rabbit") || text.includes("bunny")) detected.push(AUTO_CHARACTER_LIBRARY[0]);
  if (text.includes("fairy") || text.includes("magic")) detected.push(AUTO_CHARACTER_LIBRARY[1]);
  if (text.includes("bear") || text.includes("friend")) detected.push(AUTO_CHARACTER_LIBRARY[2]);
  if (text.includes("fox") || text.includes("villain")) detected.push(AUTO_CHARACTER_LIBRARY[3]);

  return detected.length ? detected : [AUTO_CHARACTER_LIBRARY[0], AUTO_CHARACTER_LIBRARY[1]];
};

const createStoryScenes = (storyPrompt, styleId) => {
  const lines = storyPrompt
    .split(/[\.\?\!]+/)
    .map((line) => line.trim())
    .filter(Boolean);
  const sourceLines = lines.length ? lines : [DEFAULT_STORY_PROMPT];
  const sceneCount = Math.min(5, Math.max(3, sourceLines.length));

  return Array.from({ length: sceneCount }, (_, index) => {
    const text = sourceLines[index] || sourceLines[sourceLines.length - 1];
    const title = ["Beginning", "Adventure", "Challenge", "Magic Moment", "Happy Ending"][index] || `Scene ${index + 1}`;
    return {
      id: index + 1,
      title,
      summary: `${text} ${
        index === 1
          ? "A playful surprise appears."
          : index === 2
          ? "A challenge teaches an important lesson."
          : index === 3
          ? "The scene sparkles with motion and bright colors."
          : index === 4
          ? "The story ends with joy, friendship, and dreams."
          : "The adventure begins with wonder."
      }`,
      prompt: `Create a ${styleId} scene from this sentence: ${text}`,
      subtitle: `${title}: ${text}`,
    };
  });
};

const buildNarrationText = (storyTitle, scenes) => {
  const intro = storyTitle ? `Here is the story ${storyTitle}. ` : "Here is a magical story. ";
  return [intro, ...scenes.map((scene) => `${scene.title}: ${scene.summary}`)].join(" ");
};

const buildSubtitles = (scenes) => scenes.map((scene, index) => ({ time: `${index * 4}:00`, text: scene.subtitle }));

const KidsStoryVideoMaker = () => {
  const [storyTitle, setStoryTitle] = useState("AI Kids Story Video Generator");
  const [storyPrompt, setStoryPrompt] = useState(DEFAULT_STORY_PROMPT);
  const [languageId, setLanguageId] = useState(LANGUAGE_OPTIONS[0].id);
  const [styleId, setStyleId] = useState(STYLE_OPTIONS[0].id);
  const [videoSizeId, setVideoSizeId] = useState(VIDEO_SIZE_OPTIONS[0].id);
  const [voiceType, setVoiceType] = useState(VOICE_OPTIONS[0].id);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [characterOverrides, setCharacterOverrides] = useState([]);
  const [generatedProject, setGeneratedProject] = useState(null);
  const [generatedScenes, setGeneratedScenes] = useState([]);
  const [narrationText, setNarrationText] = useState("");
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isNarrating, setIsNarrating] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const languageLabel = useMemo(
    () => LANGUAGE_OPTIONS.find((option) => option.id === languageId)?.label || "English",
    [languageId]
  );

  const styleLabel = useMemo(
    () => STYLE_OPTIONS.find((option) => option.id === styleId)?.label || "Storybook",
    [styleId]
  );

  const videoSizeLabel = useMemo(
    () => VIDEO_SIZE_OPTIONS.find((option) => option.id === videoSizeId)?.label || "YouTube",
    [videoSizeId]
  );

  useEffect(() => {
    return () => {
      window.speechSynthesis?.cancel();
      if (generatedVideoUrl) {
        URL.revokeObjectURL(generatedVideoUrl);
      }
    };
  }, [generatedVideoUrl]);

  const handleGenerateVideo = () => {
    if (!storyPrompt.trim()) {
      setError("Please paste your story so the AI can generate the video.");
      setMessage("");
      return;
    }

    setError("");
    setIsGenerating(true);
    setMessage("");

    window.setTimeout(() => {
      const title = generateStoryTitle(storyPrompt);
      const characters = characterOverrides.length ? characterOverrides : autoDetectCharacters(storyPrompt);
      const scenes = createStoryScenes(storyPrompt, styleId);
      const narration = buildNarrationText(title, scenes);
      const subtitles = buildSubtitles(scenes);
      const backgroundPrompt = `Soft, child-safe ${styleLabel.toLowerCase()} backgrounds with bright colors and gentle motion.`;
      const imagePrompts = scenes.map((scene) => `Illustrate: ${scene.summary} in ${styleLabel.toLowerCase()} style with playful characters.`);
      const videoBlob = new Blob([
        `AI Kids Story Video placeholder for ${title}`,
      ], { type: "video/mp4" });
      const previewUrl = URL.createObjectURL(videoBlob);

      setStoryTitle(title);
      setGeneratedScenes(scenes);
      setNarrationText(narration);
      setGeneratedVideoUrl(previewUrl);
      setGeneratedProject({
        title,
        storyPrompt,
        language: languageLabel,
        style: styleLabel,
        videoSize: videoSizeLabel,
        voiceType,
        characters,
        scenes,
        subtitles,
        backgroundPrompt,
        imagePrompts,
        narration,
        createdAt: new Date().toISOString(),
      });
      setIsGenerating(false);
      setMessage("Auto video generation complete. Preview and export your MP4.");
    }, 700);
  };

  const handlePlayNarration = () => {
    if (!narrationText) {
      setError("Generate the video first to play the narration.");
      return;
    }

    const speech = window.speechSynthesis;
    if (!speech) {
      setError("Speech synthesis is not supported in this browser.");
      return;
    }

    speech.cancel();
    const utterance = new SpeechSynthesisUtterance(narrationText);
    utterance.lang = LANGUAGE_OPTIONS.find((option) => option.id === languageId)?.code || "en-US";
    utterance.rate = 0.95;
    utterance.pitch = 1;
    utterance.onstart = () => setIsNarrating(true);
    utterance.onend = () => setIsNarrating(false);
    utterance.onerror = () => {
      setIsNarrating(false);
      setError("Unable to play the narration aloud.");
    };

    const voices = speech.getVoices();
    const voice = voices.find((item) => item.lang.toLowerCase().startsWith(utterance.lang.toLowerCase()));
    if (voice) {
      utterance.voice = voice;
    }

    speech.speak(utterance);
  };

  const handleDownloadVideo = () => {
    if (!generatedProject) {
      setError("Generate the video before downloading.");
      return;
    }

    const blob = new Blob([
      `AI Kids Story Video placeholder for ${generatedProject.title}`,
    ], { type: "video/mp4" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${generatedProject.title.replace(/[^a-z0-9]/gi, "_").toLowerCase() || "kids_story_video"}.mp4`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setMessage("Download started. Your MP4 package is ready.");
  };

  const handleShareWhatsApp = () => {
    if (!generatedProject) {
      setError("Generate the video before sharing.");
      return;
    }

    const text = encodeURIComponent(
      `My AI kids story video is ready: ${generatedProject.title} in ${generatedProject.language} (${generatedProject.style}).`
    );
    window.open(`https://wa.me/?text=${text}`, "_blank", "noopener,noreferrer");
  };

  const handleSaveProject = () => {
    if (!generatedProject) {
      setError("Generate the video before saving the project.");
      return;
    }

    const projectKey = `kids-story-video-project-${Date.now()}`;
    window.localStorage.setItem(projectKey, JSON.stringify(generatedProject));
    setMessage("Project saved locally in your browser for later continuation.");
  };

  const handleToggleAdvanced = () => {
    setAdvancedOpen((prev) => !prev);
    setMessage("");
  };

  const handleAddCharacter = () => {
    setCharacterOverrides((current) => [
      ...current,
      { name: "New Character", role: "Supporting", voice: "Kid Female" },
    ]);
  };

  return (
    <div className="kids-story-video-maker page-shell">
      <section className="kids-story-hero">
        <div className="kids-story-hero-copy">
          <p className="kids-story-badge">AI Kids Story Video Generator</p>
          <h1>Paste a story. Choose language. Get a cartoon video.</h1>
          <p>Quick auto mode creates scenes, characters, narration, subtitles, music, and a downloadable MP4 video.</p>
        </div>
        <div className="kids-story-hero-panel">
          <div className="story-form-card">
            <label htmlFor="storyPrompt">Paste your story</label>
            <textarea
              id="storyPrompt"
              rows={8}
              value={storyPrompt}
              onChange={(event) => setStoryPrompt(event.target.value)}
              placeholder={DEFAULT_STORY_PROMPT}
            />

            <div className="story-settings-row">
              <div>
                <label htmlFor="language">Language</label>
                <select
                  id="language"
                  value={languageId}
                  onChange={(event) => setLanguageId(event.target.value)}
                >
                  {LANGUAGE_OPTIONS.map((option) => (
                    <option key={option.id} value={option.id}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="style">Video style</label>
                <select id="style" value={styleId} onChange={(event) => setStyleId(event.target.value)}>
                  {STYLE_OPTIONS.map((option) => (
                    <option key={option.id} value={option.id}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="story-settings-row">
              <div>
                <label htmlFor="videoSize">Video size</label>
                <select
                  id="videoSize"
                  value={videoSizeId}
                  onChange={(event) => setVideoSizeId(event.target.value)}
                >
                  {VIDEO_SIZE_OPTIONS.map((option) => (
                    <option key={option.id} value={option.id}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="story-settings-empty" />
            </div>

            <p className="style-hint">{getStyleDescription(styleId)}</p>

            <div className="story-actions">
              <button className="primary-button" onClick={handleGenerateVideo} disabled={isGenerating}>
                {isGenerating ? "Generating kids video…" : "Generate Kids Video"}
              </button>
              <button
                type="button"
                className="secondary-button"
                onClick={handlePlayNarration}
                disabled={!generatedProject || isNarrating}
              >
                {isNarrating ? "Playing narration…" : "Play Narration"}
              </button>
            </div>

            <button
              type="button"
              className="download-button"
              onClick={handleDownloadVideo}
              disabled={!generatedProject}
            >
              Download MP4
            </button>

            <button
              type="button"
              className="secondary-button advanced-toggle"
              onClick={handleToggleAdvanced}
            >
              {advancedOpen ? "Hide Advanced Character Mode" : "Show Advanced Character Mode"}
            </button>

            {advancedOpen && (
              <div className="advanced-panel">
                <p className="advanced-title">Advanced Character Mode</p>
                <p className="advanced-description">Optional character controls for creators. The AI still generates scenes, narration, voice, and subtitles automatically.</p>
                <div className="character-settings-grid">
                  <div>
                    <label>Voice type</label>
                    <select value={voiceType} onChange={(event) => setVoiceType(event.target.value)}>
                      {VOICE_OPTIONS.map((option) => (
                        <option key={option.id} value={option.id}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label>Character consistency</label>
                    <select disabled>
                      <option>Auto</option>
                    </select>
                  </div>
                </div>

                <div className="character-list-header">
                  <span>Optional characters</span>
                  <button type="button" className="add-character" onClick={handleAddCharacter}>
                    Add character
                  </button>
                </div>

                {characterOverrides.map((character, index) => (
                  <div key={index} className="character-override-row">
                    <input
                      value={character.name}
                      onChange={(event) => {
                        const updated = [...characterOverrides];
                        updated[index] = { ...updated[index], name: event.target.value };
                        setCharacterOverrides(updated);
                      }}
                      placeholder="Character name"
                    />
                    <input
                      value={character.role}
                      onChange={(event) => {
                        const updated = [...characterOverrides];
                        updated[index] = { ...updated[index], role: event.target.value };
                        setCharacterOverrides(updated);
                      }}
                      placeholder="Role"
                    />
                  </div>
                ))}
              </div>
            )}

            {error && <div className="message error">{error}</div>}
            {message && !error && <div className="message success">{message}</div>}
          </div>
        </div>
      </section>

      {generatedProject && (
        <section className="kids-story-preview">
          <div className="preview-header">
            <h2>AI video preview</h2>
            <p>Review your generated story video package and export options.</p>
          </div>

          <div className="video-preview-card">
            <div className="video-preview-player">
              <div className="video-preview-poster">
                <span>Video Preview</span>
              </div>
            </div>
            <div className="video-preview-meta">
              <p><strong>Story title:</strong> {generatedProject.title}</p>
              <p><strong>Language:</strong> {generatedProject.language}</p>
              <p><strong>Style:</strong> {generatedProject.style}</p>
              <p><strong>Video size:</strong> {generatedProject.videoSize}</p>
              <p><strong>Voice:</strong> {generatedProject.voiceType}</p>
              <p><strong>Characters:</strong> {generatedProject.characters.map((character) => character.name).join(", ")}</p>
            </div>
          </div>

          <div className="preview-grid">
            {generatedScenes.map((scene) => (
              <article key={scene.id} className="scene-card">
                <div className="scene-image">{scene.title}</div>
                <div className="scene-copy">
                  <p className="scene-title">{scene.summary}</p>
                  <p className="scene-hint">{scene.subtitle}</p>
                </div>
              </article>
            ))}
          </div>

          <div className="project-actions">
            <button className="primary-button" onClick={handleDownloadVideo}>Download MP4</button>
            <button className="secondary-button" onClick={handleShareWhatsApp}>Share WhatsApp</button>
            <button className="download-button" onClick={handleSaveProject}>Save Project</button>
          </div>
        </section>
      )}
    </div>
  );
};

export default KidsStoryVideoMaker;

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import i18n from "./i18n";
import axios from "axios";
import { io } from "socket.io-client";
import { AppProvider } from "./contexts/AppContext";
import ErrorBoundary from "./components/ErrorBoundary";
import AnnouncementBar from "./components/AnnouncementBar";
import Layout from "./components/Layout";
import LaunchPage from "./components/LaunchPage";
import Login from "./components/Login";
import {
  CUSTOM_LINKS_STORAGE_KEY,
  sanitizeCustomLinks,
} from "./utils/customLinks";
import {
  clearStoredAuthToken,
  getStoredAuthToken,
  storeAuthToken,
} from "./utils/auth";
import {
  getPathForModule,
  getProtectedModuleFromPathname,
  MODULE_PATHS,
  normalizeModuleId,
  ROUTABLE_MODULES,
} from "./utils/moduleRoutes";
import { API_BASE_URL, BACKEND_BASE_URL } from "./utils/api";
import "./App.css";

const Dashboard = React.lazy(() => import("./modules/Dashboard"));
const AdminDashboard = React.lazy(() => import("./modules/admin/AdminDashboard"));
const AdminModuleSubscriptionScreen = React.lazy(() => import("./modules/admin/AdminModuleSubscriptionScreen"));
const GlobeMartEntry = React.lazy(() => import("./modules/ecommerce/GlobeMartEntry"));
const Ecommerce = React.lazy(() => import("./modules/ecommerce/Ecommerce"));
const CartPage = React.lazy(() => import("./modules/ecommerce/CartPage"));
const OrdersPage = React.lazy(() => import("./modules/ecommerce/OrdersPage"));
const ReturnsPage = React.lazy(() => import("./modules/ecommerce/ReturnsPage"));
const Messaging = React.lazy(() => import("./modules/messaging/Messaging"));
const Classifieds = React.lazy(() => import("./modules/classifieds/Classifieds"));
const RealEstate = React.lazy(() => import("./modules/realestate/RealEstate"));
const FinanceHub = React.lazy(() => import("./modules/finance/FinanceHub"));
const FreelancerMarketplace = React.lazy(() =>
  import("./modules/freelancer/FreelancerMarketplace")
);
const BillPayHub = React.lazy(() => import("./modules/billpay/BillPayHub"));
const SkillLearningHub = React.lazy(() => import("./modules/skilllearning/SkillLearningHub"));
const FoodDelivery = React.lazy(() => import("./modules/fooddelivery/FoodDelivery"));
const DevadarshanHub = React.lazy(() => import("./modules/devadarshan/DevadarshanHub"));
const HyperlocalDeliveryHub = React.lazy(() =>
  import("./modules/hyperlocal/HyperlocalDeliveryHub")
);
const LocalServicesMarketplace = React.lazy(() =>
  import("./modules/localservices/LocalServicesMarketplace")
);
const LocalMarket = React.lazy(() => import("./modules/localmarket/LocalMarket"));
const BusinessBuilder = React.lazy(() => import("./modules/businessbuilder/BusinessBuilder"));
const NilaAIHub = React.lazy(() => import("./modules/nilaaihub/NilaAIHub"));
const KidsStoryVideoMaker = React.lazy(() => import("./modules/kidsstoryvideomaker/KidsStoryVideoMaker"));
const GulfServices = React.lazy(() => import("./modules/gulfservices/GulfServices"));
const HotelBooking = React.lazy(() => import("./modules/hotelbooking/HotelBooking"));
const Healthcare = React.lazy(() => import("./modules/healthcare/Healthcare"));
const BusTrainBooking = React.lazy(() => import("./modules/bustrainbooking/BusTrainBooking"));
const ResumeBuilder = React.lazy(() => import("./modules/resumebuilder/ResumeBuilder"));
const BusinessServices = React.lazy(() => import("./modules/businessservices/BusinessServices"));
const JobPortal = React.lazy(() => import("./modules/jobportal/JobPortal"));
const Education = React.lazy(() => import("./modules/education/Education"));
const TourismMarketplace = React.lazy(() => import("./modules/tourism/TourismMarketplace"));
const RideSharing = React.lazy(() => import("./modules/ridesharing/RideSharing"));
const DriverMap = React.lazy(() => import("./modules/maps/DriverMap"));
const Matrimonial = React.lazy(() => import("./modules/matrimonial/Matrimonial"));
const SocialMedia = React.lazy(() => import("./modules/socialmedia/SocialMedia"));
const ReminderAlert = React.lazy(() => import("./modules/reminderalert/ReminderAlert"));
const QuickLinks = React.lazy(() => import("./modules/quicklinks/QuickLinks"));
const SOSAlert = React.lazy(() => import("./modules/sos/SOSAlert"));
const AstrologyHome = React.lazy(() => import("./modules/astrology/AstrologyHome"));
const ConsultantAdminPanel = React.lazy(() => import("./modules/astrology/ConsultantAdminPanel"));
const AstrologyAnalyticsDashboard = React.lazy(() => import("./modules/astrology/AnalyticsDashboard"));
const Support = React.lazy(() => import("./modules/support/Support"));
const Diary = React.lazy(() =>
  import("./modules/personaldiary").then((module) => ({ default: module.Diary }))
);
const UserProfile = React.lazy(() => import("./components/UserProfile"));

const SOCKET_BASE_URL = BACKEND_BASE_URL;
const EMERGENCY_CALL_STORAGE_KEY = "malabarbazaar-emergency-call";
const ADMIN_EMAIL = "mgdhanyamohan@gmail.com";

const buildPendingEmergencyCall = (alert = {}) => {
  const emergencyCall = alert?.emergencyCall || {};
  const callId = alert?.callId || emergencyCall.callId || emergencyCall._id || "";

  if (!callId) {
    return null;
  }

  return {
    _id: callId,
    callId,
    chatId: alert?.chatId || emergencyCall.chatId || "",
    initiatorId:
      alert?.fromUser?.id ||
      alert?.fromUser?._id ||
      emergencyCall.initiatorId ||
      "",
    recipientId: emergencyCall.recipientId || "",
    callType: alert?.callType || emergencyCall.callType || "video",
    status: emergencyCall.status || alert?.status || "ringing",
    emergency: true,
    caller: alert?.fromUser || emergencyCall.caller || {},
    timestamp: alert?.timestamp || emergencyCall.timestamp || new Date().toISOString(),
    sosAlert: {
      incidentId: alert?.incidentId || emergencyCall?.sosAlert?.incidentId || "",
      reason: alert?.reason || emergencyCall?.sosAlert?.reason || "Emergency support requested",
      location: alert?.location || emergencyCall?.sosAlert?.location || "Current Location",
      mapsUrl: alert?.mapsUrl || emergencyCall?.sosAlert?.mapsUrl || "",
      accuracy: alert?.accuracy || emergencyCall?.sosAlert?.accuracy || null,
      timestamp: alert?.timestamp || emergencyCall?.sosAlert?.timestamp || new Date().toISOString(),
      liveLocation: emergencyCall?.sosAlert?.liveLocation || null,
    },
  };
};

const EMPTY_APP_DATA = {
  businessCategories: [],
  globeMartCategories: [],
  registrationApplications: [],
  registeredAccounts: [],
  enabledModules: [],
};

const PREVIEW_ENABLED_MODULES = [
  "ecommerce",
  "messaging",
  "classifieds",
  "realestate",
  "finance",
  "freelancer",
  "billpay",
  "businessbuilder",
  "skilllearning",
  "tourism",
  "fooddelivery",
  "devadarshan",
  "hyperlocal",
  "localservices",
  "localmarket",
  "ridesharing",
  "matrimonial",
  "socialmedia",
  "reminderalert",
  "sosalert",
  "astrology",
  "kidsstoryvideomaker",
];

const TOGGLE_CONTROLLED_MODULE_IDS = [
  "ecommerce",
  "messaging",
  "classifieds",
  "realestate",
  "socialmedia",
  "matrimonial",
  "localmarket",
  "localservices",
  "hyperlocal",
  "tourism",
  "hotelbooking",
  "bustrainbooking",
  "ridesharing",
  "gulfservices",
  "businessbuilder",
  "businessservices",
  "freelancer",
  "resumebuilder",
  "jobportal",
  "skilllearning",
  "education",
  "nilaaihub",
  "kidsstoryvideomaker",
  "finance",
  "billpay",
  "fooddelivery",
  "healthcare",
  "reminderalert",
  "sosalert",
  "devadarshan",
  "astrology",
  "diary",
];

const MODULE_ACCESS_PARENT_MAP = {
  cart: "ecommerce",
  orders: "ecommerce",
  returns: "ecommerce",
};

const normalizeEnabledModules = (moduleIds = []) =>
  Array.from(
    new Set(
      (Array.isArray(moduleIds) ? moduleIds : [])
        .map((moduleId) => normalizeModuleId(moduleId))
        .filter(Boolean)
    )
  );

const PREVIEW_BUSINESS_CATEGORIES = [
  { id: "ecommerce", name: "GlobeMart", fee: 799, requiresFoodLicense: false },
  { id: "messaging", name: "LinkUp", fee: 999, requiresFoodLicense: false },
  { id: "finance", name: "Nila Finance Hub", fee: 1599, requiresFoodLicense: false },
  { id: "freelancer", name: "NilaWorks", fee: 1399, requiresFoodLicense: false },
  { id: "billpay", name: "Nila Utility Hub", fee: 1199, requiresFoodLicense: false },
  { id: "skilllearning", name: "Nila Skill Hub", fee: 999, requiresFoodLicense: false },
  { id: "tourism", name: "NilaTravel", fee: 1699, requiresFoodLicense: false },
  { id: "fooddelivery", name: "Feastly", fee: 1999, requiresFoodLicense: true },
  { id: "devadarshan", name: "Devadarshan", fee: 1299, requiresFoodLicense: false },
  { id: "hyperlocal", name: "Nila Hyperlocal Delivery", fee: 1799, requiresFoodLicense: false },
  { id: "localservices", name: "Nila Local Services Marketplace", fee: 1499, requiresFoodLicense: false },
  { id: "ridesharing", name: "SwiftRide", fee: 1499, requiresFoodLicense: false },
  { id: "matrimonial", name: "SoulMatch", fee: 899, requiresFoodLicense: false },
];

const PREVIEW_GLOBEMART_CATEGORIES = [
  {
    id: "snacks",
    name: "Kerala Snacks",
    theme: "Regional favorites",
    accentColor: "#0f4c81",
    subcategories: ["Banana Chips", "Mixtures", "Pickles"],
  },
  {
    id: "home-essentials",
    name: "Home Essentials",
    theme: "Everyday needs",
    accentColor: "#b65d24",
    subcategories: ["Cleaning", "Storage", "Kitchen"],
  },
];

const PREVIEW_REGISTRATION_APPLICATIONS = [
  {
    id: "app-101",
    applicantName: "Akhil Foods",
    businessName: "Akhil Foods",
    selectedBusinessCategories: ["fooddelivery"],
    registrationFee: 1999,
    status: "pending",
    submittedAt: "2026-05-06T09:30:00.000Z",
  },
  {
    id: "app-102",
    applicantName: "Kochi Swift Cabs",
    businessName: "Kochi Swift Cabs",
    selectedBusinessCategories: ["ridesharing"],
    registrationFee: 1499,
    status: "approved",
    submittedAt: "2026-05-05T13:15:00.000Z",
  },
];

axios.defaults.withCredentials = true;

function AppShell() {
  const navigate = useNavigate();
  const location = useLocation();
  const [authToken, setAuthToken] = useState(() => getStoredAuthToken());
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [pendingModule, setPendingModule] = useState("");
  const [authChecked, setAuthChecked] = useState(false);
  const [registrationType, setRegistrationType] = useState("");
  const [language, setLanguage] = useState("en");
  const [businessCategories, setBusinessCategories] = useState(EMPTY_APP_DATA.businessCategories);
  const [globeMartCategories, setGlobeMartCategories] = useState(
    EMPTY_APP_DATA.globeMartCategories
  );
  const [registrationApplications, setRegistrationApplications] = useState(
    EMPTY_APP_DATA.registrationApplications
  );
  const [registeredAccounts, setRegisteredAccounts] = useState(EMPTY_APP_DATA.registeredAccounts);
  const [enabledModules, setEnabledModules] = useState(EMPTY_APP_DATA.enabledModules);
  const [customLinks, setCustomLinks] = useState(() => {
    try {
      return sanitizeCustomLinks(JSON.parse(localStorage.getItem(CUSTOM_LINKS_STORAGE_KEY) || "[]"));
    } catch (error) {
      return [];
    }
  });
  const [appDataError, setAppDataError] = useState("");
  const [incomingSosAlert, setIncomingSosAlert] = useState(null);
  const [globeMartCategoryEndpointAvailable, setGlobeMartCategoryEndpointAvailable] =
    useState(true);
  const investorPreviewMode = useMemo(() => {
    const params = new URLSearchParams(location.search);
    const mode = params.get("investorPreview");
    return mode === "public" || mode === "user" || mode === "admin" ? mode : "";
  }, [location.search]);
  const investorPreviewScreen = useMemo(() => {
    const params = new URLSearchParams(location.search);
    return params.get("screen") || "";
  }, [location.search]);
  const investorPreviewEnabled = Boolean(investorPreviewMode);
  const isAdminUser =
    loggedInUser?.role === "admin" || loggedInUser?.registrationType === "admin";
  const toggleControlledModuleIds = useMemo(
    () =>
      new Set(
        [...TOGGLE_CONTROLLED_MODULE_IDS, ...businessCategories.map((category) => category?.id)]
          .map((moduleId) => normalizeModuleId(moduleId))
          .filter(Boolean)
      ),
    [businessCategories]
  );
  const defaultAuthenticatedPath = isAdminUser
    ? MODULE_PATHS["admin-dashboard"]
    : MODULE_PATHS.dashboard;

  useEffect(() => {
    i18n.changeLanguage(language);
  }, [language]);

  useEffect(() => {
    if (!authChecked || !isLoggedIn || isAdminUser) {
      return;
    }

    const activeRouteModule = getProtectedModuleFromPathname(location.pathname);
    const accessControlModule =
      MODULE_ACCESS_PARENT_MAP[activeRouteModule] || activeRouteModule;

    if (!toggleControlledModuleIds.has(accessControlModule)) {
      return;
    }

    if (!enabledModules.includes(accessControlModule)) {
      navigate(defaultAuthenticatedPath, { replace: true });
    }
  }, [
    authChecked,
    defaultAuthenticatedPath,
    enabledModules,
    isAdminUser,
    isLoggedIn,
    location.pathname,
    navigate,
    toggleControlledModuleIds,
  ]);

  const navigateToModule = useCallback(
    (moduleId, options = {}) => {
      navigate(getPathForModule(moduleId, defaultAuthenticatedPath), options);
    },
    [defaultAuthenticatedPath, navigate]
  );

  const syncAppDataFromResponse = useCallback((data = {}) => {
    setBusinessCategories(Array.isArray(data.businessCategories) ? data.businessCategories : []);
    setGlobeMartCategories(
      Array.isArray(data.globeMartCategories) ? data.globeMartCategories : []
    );
    setRegistrationApplications(
      Array.isArray(data.registrationApplications) ? data.registrationApplications : []
    );
    setRegisteredAccounts(Array.isArray(data.registeredAccounts) ? data.registeredAccounts : []);
    setEnabledModules(normalizeEnabledModules(data.enabledModules));
  }, []);

  const fetchPublicAppData = useCallback(async () => {
    const response = await axios.get(`${API_BASE_URL}/app-data/public`);
    if (!response.data?.success) {
      throw new Error("Could not load platform data.");
    }

    return response.data.data || {};
  }, []);

  const fetchAdminAppData = useCallback(async () => {
    const response = await axios.get(`${API_BASE_URL}/app-data/admin`);

    if (!response.data?.success) {
      throw new Error("Could not load admin data.");
    }

    return response.data.data || {};
  }, []);

  const loadPublicAppData = useCallback(async () => {
    try {
      const publicData = await fetchPublicAppData();
      syncAppDataFromResponse(publicData);
      setAppDataError("");
    } catch (error) {
      setAppDataError(
        error.response?.data?.message || "Backend data could not be loaded. Please start the API server."
      );
    }
  }, [fetchPublicAppData, syncAppDataFromResponse]);

  const loadAdminAppData = useCallback(async () => {
    try {
      const adminData = await fetchAdminAppData();
      syncAppDataFromResponse(adminData);
      setAppDataError("");
    } catch (error) {
      setAppDataError(
        error.response?.data?.message || "Admin data could not be loaded from the backend."
      );
    }
  }, [fetchAdminAppData, syncAppDataFromResponse]);

  useEffect(() => {
    if (authToken) {
      axios.defaults.headers.common.Authorization = `Bearer ${authToken}`;
      return;
    }

    delete axios.defaults.headers.common.Authorization;
  }, [authToken]);

  useEffect(() => {
    const query = new URLSearchParams(location.search);
    const socialProvider = String(query.get("social") || "").trim().toLowerCase();
    const redirectedToken = String(query.get("token") || "").trim();
    const socialError = String(query.get("error") || "").trim().toLowerCase();

    if (socialProvider === "google" && socialError === "not_registered") {
      setAppDataError("Google login is allowed only for registered users. Please register first.");
      query.delete("social");
      query.delete("error");
      const nextQuery = query.toString();
      navigate(
        {
          pathname: location.pathname,
          search: nextQuery ? `?${nextQuery}` : "",
        },
        { replace: true }
      );
      return;
    }

    if (!redirectedToken || socialProvider !== "google") {
      return;
    }

    storeAuthToken(redirectedToken);
    setAuthToken(redirectedToken);
    axios.defaults.headers.common.Authorization = `Bearer ${redirectedToken}`;
    query.delete("social");
    query.delete("token");
    const nextQuery = query.toString();
    navigate(
      {
        pathname: location.pathname,
        search: nextQuery ? `?${nextQuery}` : "",
      },
      { replace: true }
    );
  }, [location.pathname, location.search, navigate]);

  useEffect(() => {
    localStorage.setItem(CUSTOM_LINKS_STORAGE_KEY, JSON.stringify(customLinks));
  }, [customLinks]);

  useEffect(() => {
    if (investorPreviewEnabled) {
      return undefined;
    }

    if (!isLoggedIn || !authToken) {
      setIncomingSosAlert(null);
      return undefined;
    }

    const socket = io(SOCKET_BASE_URL, {
      auth: {
        token: authToken,
      },
      withCredentials: true,
    });

    socket.on("sos:incoming", (payload) => {
      if (!payload) {
        setIncomingSosAlert(null);
        return;
      }

      setIncomingSosAlert({
        ...payload,
        callId: payload.callId || payload.emergencyCall?.callId || "",
        chatId: payload.chatId || payload.emergencyCall?.chatId || "",
        callType: payload.callType || payload.emergencyCall?.callType || "audio",
        mapsUrl: payload.mapsUrl || payload.sosAlert?.mapsUrl || "",
        accuracy: payload.accuracy || payload.sosAlert?.accuracy || null,
      });
    });

    socket.on("call:incoming", (payload) => {
      if (payload?.emergency) {
        setIncomingSosAlert((currentAlert) => ({
          ...(currentAlert || {}),
          alertId: currentAlert?.alertId || `sos-${payload.callId}`,
          incidentId: currentAlert?.incidentId || payload.sosAlert?.incidentId || "",
          callId: payload.callId,
          chatId: payload.chatId,
          callType: payload.callType || "video",
          fromUser: payload.caller,
          location: payload.sosAlert?.location || currentAlert?.location || "Current Location",
          reason: payload.sosAlert?.reason || currentAlert?.reason || "Emergency support requested",
          timestamp: payload.sosAlert?.timestamp || currentAlert?.timestamp || new Date().toISOString(),
          mapsUrl: payload.sosAlert?.mapsUrl || currentAlert?.mapsUrl || "",
          accuracy: payload.sosAlert?.accuracy || currentAlert?.accuracy || null,
          online: true,
          emergencyCall: payload,
        }));
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [authToken, investorPreviewEnabled, isLoggedIn]);

  useEffect(() => {
    let isActive = true;

    const bootstrapAuth = async () => {
      if (investorPreviewEnabled) {
        setBusinessCategories(PREVIEW_BUSINESS_CATEGORIES);
        setGlobeMartCategories(PREVIEW_GLOBEMART_CATEGORIES);
        setRegistrationApplications(PREVIEW_REGISTRATION_APPLICATIONS);
        setRegisteredAccounts([]);
        setEnabledModules(normalizeEnabledModules(PREVIEW_ENABLED_MODULES));
        setCustomLinks([]);
        setAppDataError("");
        setIncomingSosAlert(null);
        setAuthToken("");

        if (investorPreviewMode === "public") {
          setIsLoggedIn(false);
          setLoggedInUser(null);
          setRegistrationType(investorPreviewScreen === "login" ? "login" : "");
        } else {
          const previewUser =
            investorPreviewMode === "admin"
              ? {
                  name: "NilaHub Admin",
                  email: "admin@nilahub.com",
                  avatar: "A",
                  registrationType: "admin",
                  role: "admin",
                  preferences: { language: "en" },
                }
              : {
                  name: "Dhanya",
                  email: "dhanya@nilahub.com",
                  avatar: "D",
                  registrationType: "user",
                  role: "user",
                  preferences: { language: "en" },
                };

          setRegistrationType("");
          setLoggedInUser(previewUser);
          setIsLoggedIn(true);
        }

        setLanguage("en");
        setAuthChecked(true);
        return;
      }

      if (!authToken) {
        if (isActive) {
          setAuthChecked(true);
        }
        void loadPublicAppData();
        return;
      }

      axios.defaults.headers.common.Authorization = `Bearer ${authToken}`;
      void loadPublicAppData();

      try {
        const authResponse = await axios.get(`${API_BASE_URL}/auth/me`, {
          validateStatus: (status) => status === 200 || status === 401,
        });

        if (!isActive) {
          return;
        }

        if (authResponse.status === 401) {
          clearStoredAuthToken();
          setAuthToken("");
          setIsLoggedIn(false);
          setLoggedInUser(null);
          setAuthChecked(true);
          return;
        }

        if (!authResponse.data?.success || !authResponse.data.user) {
          setAuthChecked(true);
          return;
        }

        const normalizedEmail = String(authResponse.data.user.email || "")
          .trim()
          .toLowerCase();
        const hasAdminAccess =
          normalizedEmail === ADMIN_EMAIL ||
          authResponse.data.user.registrationType === "admin" ||
          authResponse.data.user.role === "admin";

        const nextUser = {
          ...authResponse.data.user,
          registrationType: hasAdminAccess ? "admin" : "user",
          role: hasAdminAccess ? "admin" : authResponse.data.user.role || "user",
          avatar: hasAdminAccess ? "A" : authResponse.data.user.avatar,
        };

        setLanguage(nextUser.preferences?.language || "en");
        setLoggedInUser(nextUser);
        setIsLoggedIn(true);
        setAuthChecked(true);

        if (hasAdminAccess) {
          void loadAdminAppData();
        }
      } catch (authError) {
        if (!isActive) {
          return;
        }

        if (authError.response?.status && authError.response.status !== 401) {
          setAppDataError(
            authError.response?.data?.message ||
              authError.message ||
              "Backend data could not be loaded. Please start the API server."
          );
        }

        setIsLoggedIn(false);
        setLoggedInUser(null);
        setAuthChecked(true);
      }
    };

    bootstrapAuth();

    return () => {
      isActive = false;
    };
  }, [
    authToken,
    investorPreviewEnabled,
    investorPreviewMode,
    investorPreviewScreen,
    loadAdminAppData,
    loadPublicAppData,
  ]);

  const handleLoginSuccess = useCallback(
    async (user, _token, activeRole) => {
      const normalizedEmail = String(user?.email || "")
        .trim()
        .toLowerCase();
      const hasAdminAccess =
        normalizedEmail === ADMIN_EMAIL ||
        activeRole === "admin" ||
        user.registrationType === "admin" ||
        user.role === "admin";
      const resolvedRegistrationType = hasAdminAccess ? "admin" : "user";
      const nextAuthToken = _token || authToken;

      if (nextAuthToken) {
        storeAuthToken(nextAuthToken);
        setAuthToken(nextAuthToken);
        axios.defaults.headers.common.Authorization = `Bearer ${nextAuthToken}`;
      }

      let nextUser = {
        ...user,
        registrationType: resolvedRegistrationType,
        role: resolvedRegistrationType === "admin" ? "admin" : user.role || "user",
        avatar: resolvedRegistrationType === "admin" ? "A" : user.avatar,
      };

      try {
        const nextAppData =
          resolvedRegistrationType === "admin"
            ? await fetchAdminAppData()
            : await fetchPublicAppData();

        syncAppDataFromResponse(nextAppData);
        setAppDataError("");

        const profileResponse = await axios.patch(`${API_BASE_URL}/auth/me`, {
          registrationType: resolvedRegistrationType,
          role: resolvedRegistrationType === "admin" ? "admin" : nextUser.role || "user",
          phone: nextUser.phone || "",
          location: nextUser.location || "",
          businessName: nextUser.businessName || "",
          selectedBusinessCategories: nextUser.selectedBusinessCategories || [],
          selectedCategoryDetails:
            nextUser.selectedCategoryDetails || nextUser.selectedBusinessCategories || [],
        });

        if (profileResponse.data?.success && profileResponse.data.user) {
          nextUser = {
            ...nextUser,
            ...profileResponse.data.user,
          };
        }
      } catch (error) {
        setAppDataError(
          error.response?.data?.message || "Shared platform data could not be refreshed."
        );
      }

      setLanguage(nextUser.preferences?.language || "en");
      setLoggedInUser(nextUser);
      setIsLoggedIn(true);

      const currentRouteModule = getProtectedModuleFromPathname(location.pathname);
      const currentAccessModule =
        MODULE_ACCESS_PARENT_MAP[currentRouteModule] || currentRouteModule;
      const currentPathIsProtected = ROUTABLE_MODULES.has(currentRouteModule);
      const defaultPathForRole =
        resolvedRegistrationType === "admin"
          ? MODULE_PATHS["admin-dashboard"]
          : MODULE_PATHS.dashboard;

      const normalizedPendingModule = normalizeModuleId(pendingModule);
      const nextModule =
        resolvedRegistrationType === "admin"
          ? "admin-dashboard"
          : normalizedPendingModule && enabledModules.includes(normalizedPendingModule)
            ? normalizedPendingModule
            : currentPathIsProtected &&
                (!toggleControlledModuleIds.has(currentAccessModule) ||
                  enabledModules.includes(currentAccessModule))
              ? currentAccessModule
              : "dashboard";

      setPendingModule("");
      navigate(getPathForModule(nextModule, defaultPathForRole), { replace: true });
    },
    [
      enabledModules,
      fetchAdminAppData,
      fetchPublicAppData,
      authToken,
      location.pathname,
      navigate,
      pendingModule,
      syncAppDataFromResponse,
      toggleControlledModuleIds,
    ]
  );

  const handleLogout = async () => {
    try {
      await axios.post(`${API_BASE_URL}/auth/logout`);
    } catch (error) {
      // Clear local app state even if the backend logout request fails.
    }
    clearStoredAuthToken();
    setAuthToken("");
    delete axios.defaults.headers.common.Authorization;
    setIsLoggedIn(false);
    setLoggedInUser(null);
    setPendingModule("");
    setRegistrationType("");
    setLanguage("en");
    navigate("/", { replace: true });
  };

  const handleOpenEmergencyModule = useCallback((nextModule) => {
    if (nextModule === "messaging" && incomingSosAlert) {
      const pendingEmergencyCall = buildPendingEmergencyCall(incomingSosAlert);

      if (pendingEmergencyCall) {
        sessionStorage.setItem(
          EMERGENCY_CALL_STORAGE_KEY,
          JSON.stringify(pendingEmergencyCall)
        );
        window.dispatchEvent(
          new CustomEvent("malabarbazaar:emergency-call", {
            detail: pendingEmergencyCall,
          })
        );
      }
    }

    setIncomingSosAlert(null);
    navigateToModule(nextModule);
  }, [incomingSosAlert, navigateToModule]);

  const handleSelectRegistrationType = (type, targetModule = "") => {
    setRegistrationType(type);
    setPendingModule(targetModule);
  };

  const handleBackToLaunch = () => {
    setRegistrationType("");
    setPendingModule("");
  };

  const handleLanguageChange = async (nextLanguage) => {
    setLanguage(nextLanguage);

    if (!isLoggedIn) {
      return;
    }

    try {
      const response = await axios.patch(`${API_BASE_URL}/auth/me`, {
        preferences: {
          language: nextLanguage,
        },
      });

      if (response.data?.success && response.data.user) {
        setLoggedInUser(response.data.user);
      }
    } catch (error) {
      setAppDataError(
        error.response?.data?.message || "Language preference could not be saved."
      );
    }
  };

  const handleProfileUpdate = useCallback((updatedUser) => {
    if (!updatedUser) {
      return;
    }

    setLoggedInUser((currentUser) => ({
      ...(currentUser || {}),
      ...updatedUser,
    }));
  }, []);

  useEffect(() => {
    if (!isLoggedIn) {
      return;
    }

    const query = new URLSearchParams(location.search);
    const gateway = query.get("gateway");
    const paymentState = query.get("payment");

    if (gateway === "stripe" && (paymentState === "success" || paymentState === "cancelled")) {
      if (location.pathname !== MODULE_PATHS.orders) {
        navigate(
          {
            pathname: MODULE_PATHS.orders,
            search: location.search,
          },
          { replace: true }
        );
      }
    }
  }, [isLoggedIn, location.pathname, location.search, navigate]);

  useEffect(() => {
    if (!isLoggedIn) {
      return;
    }

    const query = new URLSearchParams(location.search);
    const requestedModule = String(query.get("module") || "").trim();
    if (!requestedModule) {
      return;
    }

    if (!ROUTABLE_MODULES.has(requestedModule)) {
      return;
    }

    query.delete("module");
    const nextQuery = query.toString();
    navigate(
      {
        pathname: getPathForModule(requestedModule, defaultAuthenticatedPath),
        search: nextQuery ? `?${nextQuery}` : "",
      },
      { replace: true }
    );
  }, [defaultAuthenticatedPath, isLoggedIn, location.search, navigate]);

  const handleRegistrationSubmit = useCallback(
    async (application) => {
      const payload = new FormData();
      const { files = {}, ...applicationFields } = application || {};

      Object.entries(applicationFields).forEach(([key, value]) => {
        if (Array.isArray(value) || (value && typeof value === "object")) {
          payload.append(key, JSON.stringify(value));
          return;
        }

        payload.append(key, value ?? "");
      });

      Object.entries(files).forEach(([key, file]) => {
        if (file) {
          payload.append(key, file);
        }
      });

      const response = await axios.post(
        `${API_BASE_URL}/app-data/registration-applications`,
        payload
      );

      if (!response.data?.success) {
        throw new Error("Registration could not be saved.");
      }

      setRegistrationApplications(response.data.data?.registrationApplications || []);
      setRegisteredAccounts(response.data.data?.registeredAccounts || []);
    },
    []
  );

  const handleToggleModule = useCallback(async (moduleId) => {
    try {
      const response = await axios.patch(
        `${API_BASE_URL}/app-data/enabled-modules/${moduleId}`,
        {}
      );

      if (!response.data?.success) {
        throw new Error("Module update failed.");
      }

      setEnabledModules(normalizeEnabledModules(response.data.data?.enabledModules));
      setAppDataError("");
      return true;
    } catch (error) {
      setAppDataError(
        error.response?.data?.message || "Module visibility could not be updated."
      );
      return false;
    }
  }, []);

  const handleReviewRegistration = useCallback(async (applicationId, action, reason) => {
    const response = await axios.patch(
      `${API_BASE_URL}/app-data/registration-applications/${applicationId}/review`,
      { action, reason }
    );

    if (!response.data?.success) {
      throw new Error("Registration review update failed.");
    }

    setRegistrationApplications(response.data.data?.registrationApplications || []);
    return response.data;
  }, []);

  const handleCreateGlobeMartCategory = useCallback(async (categoryInput) => {
    const normalizedCategory =
      typeof categoryInput === "string"
        ? { name: categoryInput.trim(), theme: "", accentColor: "", subcategories: [] }
        : {
            name: String(categoryInput?.name || "").trim(),
            theme: String(categoryInput?.theme || "").trim(),
            accentColor: String(categoryInput?.accentColor || "").trim(),
            subcategories: Array.isArray(categoryInput?.subcategories)
              ? categoryInput.subcategories.filter(Boolean)
              : [],
          };
    const trimmedName = normalizedCategory.name;

    const mergeLocalCategory = (currentCategories) => {
      const safeCategories = Array.isArray(currentCategories) ? currentCategories : [];
      const alreadyExists = safeCategories.some((category) => {
        const name =
          typeof category === "string"
            ? category
            : String(category?.name || category?.label || category?.id || "");

        return name.trim().toLowerCase() === trimmedName.toLowerCase();
      });

      return alreadyExists ? safeCategories : [...safeCategories, normalizedCategory];
    };

    if (!globeMartCategoryEndpointAvailable) {
      setGlobeMartCategories((currentCategories) => mergeLocalCategory(currentCategories));
      return { persisted: false };
    }

    try {
      const response = await axios.post(
        `${API_BASE_URL}/app-data/globemart-categories`,
        normalizedCategory
      );

      if (!response.data?.success) {
        throw new Error("GlobeMart category creation failed.");
      }

      const nextCategories = Array.isArray(response.data.data?.globeMartCategories)
        ? response.data.data.globeMartCategories
        : mergeLocalCategory(globeMartCategories);

      setGlobeMartCategories(nextCategories);
      setGlobeMartCategoryEndpointAvailable(true);
      return { persisted: true };
    } catch (error) {
      if (error.response?.status === 404) {
        setGlobeMartCategoryEndpointAvailable(false);
        setGlobeMartCategories((currentCategories) => mergeLocalCategory(currentCategories));
        return { persisted: false };
      }

      throw error;
    }
  }, [globeMartCategories, globeMartCategoryEndpointAvailable]);

  const handleAddGlobeMartSubcategory = useCallback(
    async (categoryId, subcategoryName) => {
      const trimmedSubcategory = String(subcategoryName || "").trim();

      const mergeLocalSubcategory = (currentCategories) =>
        (Array.isArray(currentCategories) ? currentCategories : []).map((category) => {
          if (typeof category === "string") {
            const normalizedName = category.trim();
            const normalizedId = normalizedName.toLowerCase().replace(/[^a-z0-9]+/g, "-");

            if (categoryId !== normalizedId && categoryId !== normalizedName) {
              return category;
            }

            return {
              id: normalizedId,
              name: normalizedName,
              theme: "",
              accentColor: "",
              subcategories: [trimmedSubcategory],
            };
          }

          if (category?.id !== categoryId) {
            return category;
          }

          const currentSubcategories = Array.isArray(category?.subcategories)
            ? category.subcategories
            : [];
          const alreadyExists = currentSubcategories.some(
            (item) => String(item || "").trim().toLowerCase() === trimmedSubcategory.toLowerCase()
          );

          return alreadyExists
            ? category
            : { ...category, subcategories: [...currentSubcategories, trimmedSubcategory] };
        });

      try {
        const response = await axios.post(
          `${API_BASE_URL}/app-data/globemart-categories/${categoryId}/subcategories`,
          { subcategory: trimmedSubcategory }
        );

        if (!response.data?.success) {
          throw new Error("GlobeMart subcategory creation failed.");
        }

        setGlobeMartCategories(
          Array.isArray(response.data.data?.globeMartCategories)
            ? response.data.data.globeMartCategories
            : mergeLocalSubcategory(globeMartCategories)
        );
        return { persisted: true };
      } catch (error) {
        if (error.response?.status === 404) {
          setGlobeMartCategories((currentCategories) => mergeLocalSubcategory(currentCategories));
          return { persisted: false };
        }

        throw error;
      }
    },
    [globeMartCategories]
  );

  if (!authChecked) {
    return (
      <>
        <AnnouncementBar language={language} />
        <div className="app-loading">Loading NilaHub...</div>
      </>
    );
  }

  if (!isLoggedIn) {
    if (!registrationType) {
      return (
        <>
          <AnnouncementBar language={language} />
          <LaunchPage
            language={language}
            onLanguageChange={handleLanguageChange}
            onSelectRegistrationType={handleSelectRegistrationType}
            enabledModules={enabledModules}
            customLinks={customLinks}
          />
          {appDataError && <div className="app-loading">{appDataError}</div>}
        </>
      );
    }

    return (
      <>
        <AnnouncementBar language={language} />
        <Login
          language={language}
          registrationType={registrationType}
          businessCategories={businessCategories}
          registeredAccounts={registeredAccounts}
          onBackToLaunch={handleBackToLaunch}
          onRegistrationSubmit={handleRegistrationSubmit}
          onLoginSuccess={handleLoginSuccess}
          enabledModules={enabledModules}
        />
      </>
    );
  }

  return (
    <ErrorBoundary>
      <AppProvider loggedInUser={loggedInUser} language={language} authToken={authToken}>
        <React.Suspense fallback={<div className="app-loading">Loading app modules...</div>}>
          <Routes>
            <Route
              path="/"
              element={
                <Layout
                  loggedInUser={loggedInUser}
                  onLogout={handleLogout}
                  language={language}
                  appDataError={appDataError}
                  enabledModules={enabledModules}
                />
              }
            >
              <Route index element={<Navigate to={defaultAuthenticatedPath} replace />} />
              <Route
                path="dashboard"
                element={
                  <Dashboard
                    enabledModules={enabledModules}
                    customLinks={customLinks}
                  />
                }
              />
              <Route
                path="admin-dashboard"
                element={
                  isAdminUser ? (
                    <AdminDashboard
                      businessCategories={businessCategories}
                      globeMartCategories={globeMartCategories}
                      registrationApplications={registrationApplications}
                      registeredAccounts={registeredAccounts}
                      onReviewRegistration={handleReviewRegistration}
                      onCreateGlobeMartCategory={handleCreateGlobeMartCategory}
                      onAddGlobeMartSubcategory={handleAddGlobeMartSubcategory}
                      enabledModules={enabledModules}
                      onToggleModule={handleToggleModule}
                    />
                  ) : (
                    <Navigate to={MODULE_PATHS.dashboard} replace />
                  )
                }
              />
              <Route
                path="admin-dashboard/subscriptions"
                element={
                  isAdminUser ? (
                    <AdminModuleSubscriptionScreen />
                  ) : (
                    <Navigate to={MODULE_PATHS.dashboard} replace />
                  )
                }
              />
              <Route
                path="ecommerce"
                element={
                  <GlobeMartEntry
                    globeMartCategories={globeMartCategories}
                    businessCategories={businessCategories}
                    loggedInUser={loggedInUser}
                  />
                }
              />
              <Route path="cart" element={<CartPage />} />
              <Route path="orders" element={<OrdersPage />} />
              <Route path="returns" element={<ReturnsPage />} />
              
              <Route path="messaging" element={<Messaging />} />
              <Route path="classifieds" element={<Classifieds />} />
              <Route path="realestate" element={<RealEstate />} />
              <Route path="finance" element={<FinanceHub />} />
              <Route path="business-builder" element={<BusinessBuilder />} />
              <Route path="nila-ai-hub" element={<NilaAIHub />} />
              <Route path="kids-story-video-maker" element={<KidsStoryVideoMaker />} />
              <Route path="gulf-services" element={<GulfServices />} />
              <Route path="hotelbooking" element={<HotelBooking />} />
              <Route path="healthcare" element={<Healthcare />} />
              <Route path="bustrainbooking" element={<BusTrainBooking />} />
              <Route path="resumebuilder" element={<ResumeBuilder />} />
              <Route path="businessservices" element={<BusinessServices />} />
              <Route path="jobportal" element={<JobPortal />} />
              <Route path="education" element={<Education />} />
              <Route path="tourism" element={<TourismMarketplace />} />
              <Route path="freelancer" element={<FreelancerMarketplace />} />
              <Route path="billpay" element={<BillPayHub />} />
              <Route path="skilllearning" element={<SkillLearningHub />} />
              <Route path="fooddelivery" element={<FoodDelivery />} />
              <Route path="devadarshan" element={<DevadarshanHub />} />
              <Route path="hyperlocal" element={<HyperlocalDeliveryHub />} />
              <Route path="localservices" element={<LocalServicesMarketplace />} />
              <Route path="localmarket" element={<LocalMarket />} />
              <Route path="ridesharing" element={<RideSharing />} />
              <Route path="ridesharing/driver-map" element={<DriverMap />} />
              <Route path="maps" element={<DriverMap />} />
              <Route
                path="matrimonial"
                element={<Matrimonial onProfileUpdate={handleProfileUpdate} />}
              />
              <Route path="socialmedia" element={<SocialMedia />} />
              <Route
                path="reminderalert"
                element={<ReminderAlert />}
              />
              <Route
                path="quicklinks"
                element={
                  <QuickLinks customLinks={customLinks} onCustomLinksChange={setCustomLinks} />
                }
              />
              <Route path="diary" element={<Diary />} />
              <Route path="sosalert" element={<SOSAlert />} />
              <Route path="astrology" element={<AstrologyHome />} />
              <Route path="astrology-consultant-admin" element={<ConsultantAdminPanel />} />
              <Route path="astrology-analytics" element={<AstrologyAnalyticsDashboard />} />
              <Route path="support" element={<Support />} />
              <Route 
                path="profile" 
                element={
                  <UserProfile 
                    loggedInUser={loggedInUser}
                    onProfileUpdate={handleProfileUpdate}
                  />
                } 
              />
              <Route path="*" element={<Navigate to={defaultAuthenticatedPath} replace />} />
            </Route>
          </Routes>
        </React.Suspense>
        {incomingSosAlert ? (
          <div className="emergency-call-overlay">
            <div className="emergency-call-modal">
              <span className="emergency-call-kicker">Emergency Alert</span>
              <h2>{incomingSosAlert.fromUser?.name || incomingSosAlert.fromUser?.email || "A contact"} needs help</h2>
              <p>
                {incomingSosAlert.reason} near {incomingSosAlert.location}.
              </p>
              <p className="emergency-call-meta">
                In-app SOS {incomingSosAlert.callType === "video" ? "video call" : "call"} requested at {new Date(incomingSosAlert.timestamp).toLocaleTimeString("en-IN", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
              <div className="emergency-call-actions">
                <button
                  type="button"
                  className="emergency-call-primary"
                  onClick={() => handleOpenEmergencyModule("messaging")}
                >
                  {incomingSosAlert.callType === "video" ? "Join Emergency Video Call" : "Open Messaging"}
                </button>
                <button
                  type="button"
                  className="emergency-call-secondary"
                  onClick={() => handleOpenEmergencyModule("sosalert")}
                >
                  Open SOS Center
                </button>
                <button
                  type="button"
                  className="emergency-call-secondary"
                  onClick={() => setIncomingSosAlert(null)}
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        ) : null}
      </AppProvider>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AppShell />
    </BrowserRouter>
  );
}

export default App;
